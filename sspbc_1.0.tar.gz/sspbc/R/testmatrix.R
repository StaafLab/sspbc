#' @title A gene expression matrix to be used as an example set
#'
#' @description
#' An example dataset with gene expression data (FPKM) from StringTie.
#'
#' @docType data
#' @usage data(testmatrix)
#'
#' @details
#' Gene expression data is summarized on GENCODE gene identifier.
#' Gene definitions are from GENCODE Release 27.
#' The matrix contain data from 9 samples (columns).   
#' Row names are GENCODE gene identifiers (Gene.ID).
#'
#' @return
#' \item{testmatrix}{A matrix of raw gene expression data with rows as gene and columns as samples.}
#'
"testmatrix"
