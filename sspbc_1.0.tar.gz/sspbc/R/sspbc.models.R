#' @title The sspbc models (short name) for the 11 developed predictors
#'
#' @description
#' List with the 11 SSP models from Staaf J. et al. medRxiv 2021.12.03.21267116.
#'
#' @docType data
#' @usage data(sspbc.models)
#'
#' @details
#' List elements are named with short name for respective ssp model.
#' The ssp models in list sspbc.models are the same as in list sspbc.models.fullname.
#'
#' @return
#' \item{sspbc.models}{The collection of 11 ssp models used by sspbc.}
#'
#' @author
#' Johan Staaf (johan.staaf@@med.lu.se),
#' Johan Vallon-Christersson (johan.vallon-christersson@@med.lu.se)
#'
#' @seealso
#' \code{\link{applySSP}
#' \link{sspbc.models.fullname}
#' \link{Gene.ID.ann}
#' \link{testmatrix}
#' }
#'
#' @references
#' Staaf J. et al. medRxiv 2021.12.03.21267116
#' (\href{https://doi.org/10.1101/2021.12.03.21267116}{medRxiv})
#' (\href{https://github.com/StaafLab/sspbc}{GitHub})
#'
#' @examples
#' ## Load the sspbc.models
#' data(sspbc.models)
#'
#'
"sspbc.models"
