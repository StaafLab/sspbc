#' @title The sspbc models (full name) for the 11 developed predictors
#'
#' @description
#' List with the 11 SSP models from Staaf J. et al. medRxiv 2021.12.03.21267116.
#'
#' @docType data
#' @usage data(sspbc.models.fullname)
#'
#' @details
#' List elements are named with full name for respective ssp model.
#' Note that ssp models in list sspbc.models.fullname are the same as in list sspbc.models.
#'
#' @return
#' \item{sspbc.models.fullname}{The collection of 11 ssp models used by sspbc.}
#'
#' @author
#' Johan Staaf (johan.staaf@@med.lu.se),
#' Johan Vallon-Christersson (johan.vallon-christersson@@med.lu.se)
#'
#' @seealso
#' \code{\link{applySSP}
#' \link{sspbc.models}
#' \link{Gene.ID.ann}
#' \link{testmatrix}
#' }
#'
#' @references
#' Staaf J. et al. medRxiv 2021.12.03.21267116
#' (\href{https://doi.org/10.1101/2021.12.03.21267116}{medRxiv})
#' (\href{https://github.com/StaafLab/sspbc}{GitHub})
#'
#' @examples
#' ## Load the sspbc.models
#' data(sspbc.models.fullname)
#'
#'
"sspbc.models.fullname"
