#' @title Gene annotation table.
#'
#' @description
#' Annotation table for the GENCODE Human Release 27 genes (Gene.ID) included in the StringTie target when summarizing gene expression.
#' The annotation are from from GENCODE Human Release 27 metadata files and include HGNC, EntrezGene and RefSeq.
#'
#' @docType data
#' @usage data(Gene.ID.ann)
#'
#' @details
#' Annotation table used by the applySSP to translate gene identifiers as needed before classification with provided ssp models.
#'
#' @return
#' \item{Gene.ID.ann}{Annotation table for GENCODE Human Release 27 genes.}
#'
#' @author
#' Johan Staaf (johan.staaf@@med.lu.se),
#' Johan Vallon-Christersson (johan.vallon-christersson@@med.lu.se)
#'
#' @seealso
#' \code{\link{applySSP}
#' \link{sspbc.models}
#' \link{sspbc.models.fullname}
#' \link{testmatrix}
#' }
#'
#' @references
#' Staaf J. et al. medRxiv 2021.12.03.21267116
#' (\href{https://doi.org/10.1101/2021.12.03.21267116}{medRxiv})
#' (\href{https://github.com/StaafLab/sspbc}{GitHub})
#'
#' @examples
#' ## Load the Gene.ID.ann
#' data(Gene.ID.ann)
#'
#'
"Gene.ID.ann"
